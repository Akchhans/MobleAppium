package day1;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;

public class TestSwipe {
	public static AndroidDriver<MobileElement> driver;
public static boolean isElementPresent(String id){
		
		try{
		driver.findElement(By.id(id));
		return true;
		}catch(Throwable t){
			
			return false;
		}
	}
	public static void main(String[] args) throws MalformedURLException, InterruptedException {

		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability("deviceName", "Android");

		capabilities.setCapability("appPackage", "in.amazon.mShop.android.shopping");
		capabilities.setCapability("appActivity", "com.amazon.mShop.home.HomeActivity");

		driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);

		driver.manage().timeouts().implicitlyWait(10L, TimeUnit.SECONDS);
		if(isElementPresent("in.amazon.mShop.android.shopping:id/skip_sign_in_button")){
			
			driver.findElement(By.id("in.amazon.mShop.android.shopping:id/skip_sign_in_button")).click();
			}
		driver.findElement(By.id("in.amazon.mShop.android.shopping:id/rs_search_src_text")).click();
		driver.findElement(By.id("in.amazon.mShop.android.shopping:id/rs_search_src_text")).sendKeys("lightbulb");

		driver.pressKeyCode(AndroidKeyCode.ENTER);

		Thread.sleep(3000);
		/*String text = "Leewon";
		driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector().resourceId(\"in.amazon.mShop.android.shopping:id/rs_item_byline\"))).scrollIntoView(new UiSelector().textContains(\""+text+"\"))").click();
		*/
		
		List<MobileElement> names = driver.findElements(By.id("in.amazon.mShop.android.shopping:id/rs_item_byline"));
		Thread.sleep(3000);
		try {
			while (true) {

				for (MobileElement name : names) {

					if (name.getText().startsWith("Happy Is the New Rich: (And 207 Other Lightbulb Moments)")) {

						name.click();
						break;
					}

				}
				

				driver.swipe(500, 1500, 500, 200, 5000);
				
			}
		} catch (Throwable t) {
			
			System.out.println("error occured **********");

		}

		Thread.sleep(4000);
		driver.quit();
	}

}

package day1;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;

public class TestDialingNumbers {
	public static AndroidDriver<MobileElement> driver;


	public static boolean isElementPresent(String id){
		
		try{
		driver.findElement(By.id(id));
		return true;
		}catch(Throwable t){
			
			return false;
		}
	}
	

	public static void main(String[] args) throws MalformedURLException, InterruptedException {
		
		/*	AppiumDriverLocalService service = AppiumDriverLocalService
				.buildService(new AppiumServiceBuilder()
						.usingDriverExecutable(new File("C:\\Program Files (x86)\\Appium\\node.exe"))
						.withAppiumJS(new File("C:\\Program Files (x86)\\Appium\\node_modules\\appium\\bin\\appium.js"))
						.withLogFile(new File("c:\\appiumlogs\\logs.txt")));
				
				service.start();*/
			
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability("deviceName","ZY223D5GZZ");
		
		capabilities.setCapability("deviceName", "Android");
		capabilities.setCapability("appPackage", "com.android.dialer");
		capabilities.setCapability("appActivity", "com.android.dialer.DialtactsActivity");
		
		driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);

		driver.findElement(By.id("floating_action_button")).click();
		driver.findElement(By.id("com.android.dialer:id/one")).click();
		driver.findElement(By.id("com.android.dialer:id/three")).click();
		driver.findElement(By.id("com.android.dialer:id/five")).click();
		driver.findElement(By.id("com.android.dialer:id/two")).click();
		driver.findElement(By.id("com.android.dialer:id/four")).click();
		driver.findElement(By.id("com.android.dialer:id/seven")).click();
		driver.findElement(By.id("com.android.dialer:id/dialpad_floating_action_button")).click();
		
		
		Thread.sleep(5000);
		driver.quit();
		//service.stop();
		
	}

}

package selenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class AppiumWeb {
	public static String driverPath = "C:\\Users\\akcsingh\\Downloads\\chromedriver_win32\\";
	public static WebDriver driver;

	public static void main(String[] args) throws Throwable {
		System.out.println("launching chrome browser");
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://wikipedia.org");
		// driver.manage().deleteAllCookies();
		Thread.sleep(3000);

		WebElement dropdown = driver.findElement(By.id("searchLanguage"));
		Select select = new Select(dropdown);
		select.selectByValue("hi");
		// select.getOptions();

		List<WebElement> values = dropdown.findElements(By.tagName("option"));

		System.out.println(values.size());

		for (WebElement value : values) {

			System.out.println(value.getAttribute("lang"));

		}
		System.out.println("----Printing links-------");

		WebElement block = driver.findElement(By.cssSelector(".other-projects"));

		List<WebElement> links = block.findElements(By.tagName("a"));

		System.out.println(links.size());

		for (WebElement link : links) {

			System.out.println(link.getAttribute("href") + "----" + link.getText());

		}
		Thread.sleep(2000);
		driver.quit();

	}

}
